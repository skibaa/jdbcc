select * from CATEGORY;
